#!/usr/bin/env bash
set -euo pipefail

PMEM_MOUNT="${PMEM_MOUNT:-/mnt/pmem}"
PMEM_DIR="${HBALLOC_PMEM_DIR:-$PMEM_MOUNT/HBalloc}"

missing=0
for tool in gcc make findmnt taskset; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "missing required tool: $tool" >&2
        missing=1
    fi
done

if [[ "$missing" -ne 0 ]]; then
    exit 1
fi

if ! findmnt -T "$PMEM_MOUNT" >/dev/null 2>&1; then
    echo "persistent-memory mount not found: $PMEM_MOUNT" >&2
    exit 1
fi

if ! findmnt -T "$PMEM_MOUNT" -n -o OPTIONS | grep -q 'dax'; then
    echo "mount exists but does not appear to be DAX-enabled: $PMEM_MOUNT" >&2
    findmnt -T "$PMEM_MOUNT" -n -o TARGET,FSTYPE,OPTIONS >&2 || true
    exit 1
fi

if [[ ! -d "$PMEM_DIR" ]]; then
    echo "persistent-memory directory does not exist: $PMEM_DIR" >&2
    echo "create it with: sudo mkdir -p $PMEM_DIR" >&2
    exit 1
fi

if [[ ! -w "$PMEM_DIR" ]]; then
    echo "persistent-memory directory is not writable: $PMEM_DIR" >&2
    echo "fix ownership with: sudo chown $(id -u):$(id -g) $PMEM_DIR" >&2
    exit 1
fi

echo "HBalloc artifact environment looks usable."
echo "PMEM_MOUNT=$PMEM_MOUNT"
echo "HBALLOC_PMEM_DIR=$PMEM_DIR"
findmnt -T "$PMEM_MOUNT" -n -o TARGET,FSTYPE,OPTIONS
