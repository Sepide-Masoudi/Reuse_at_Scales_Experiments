#!/usr/bin/env python3
import csv
import re
import sys
from pathlib import Path


THREAD_RE = re.compile(r"^===== threads=(\d+) =====$")
ALLOC_RE = re.compile(r"^Allocation throughput = ([0-9.]+) Mops/s$")
MALLOC_FREE_RE = re.compile(r"^Malloc\+free throughput = ([0-9.]+) Mops/s$")
TIME_RE = re.compile(r"^(?:Execution time|Time) = ([0-9.]+) s$")
THROUGHPUT_RE = re.compile(r"^Throughput = ([0-9.]+) Mops/s$")
VERIFY_RE = re.compile(
    r"^Verified operations = (\d+) allocations \+ (\d+) frees$"
)


def parse_file(path):
    rows = []
    current = None

    for raw in path.read_text(errors="replace").splitlines():
        line = raw.strip()
        match = THREAD_RE.match(line)
        if match:
            if current is not None:
                rows.append(current)
            current = {
                "file": str(path),
                "threads": match.group(1),
                "allocation_mops": "",
                "malloc_free_mops": "",
                "time_seconds": "",
                "verified_allocations": "",
                "verified_frees": "",
            }
            continue

        if current is None:
            continue

        match = ALLOC_RE.match(line)
        if match:
            current["allocation_mops"] = match.group(1)
            continue

        match = MALLOC_FREE_RE.match(line)
        if match:
            current["malloc_free_mops"] = match.group(1)
            continue

        match = TIME_RE.match(line)
        if match:
            current["time_seconds"] = match.group(1)
            continue

        match = THROUGHPUT_RE.match(line)
        if match and not current["allocation_mops"]:
            current["allocation_mops"] = match.group(1)
            continue

        match = VERIFY_RE.match(line)
        if match:
            current["verified_allocations"] = match.group(1)
            current["verified_frees"] = match.group(2)

    if current is not None:
        rows.append(current)

    return rows


def main(argv):
    if len(argv) < 2:
        print(f"usage: {argv[0]} LOG...", file=sys.stderr)
        return 2

    fieldnames = [
        "file",
        "threads",
        "allocation_mops",
        "malloc_free_mops",
        "time_seconds",
        "verified_allocations",
        "verified_frees",
    ]
    writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)
    writer.writeheader()

    for name in argv[1:]:
        for row in parse_file(Path(name)):
            writer.writerow(row)

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
