#!/usr/bin/env bash
set -euo pipefail

PMEM_MOUNT="${PMEM_MOUNT:-/mnt/pmem}"
PMEM_DIR="${HBALLOC_PMEM_DIR:-$PMEM_MOUNT/HBalloc}"

section() {
    printf '\n## %s\n' "$1"
}

section "date"
date -Is

section "git"
git rev-parse HEAD 2>/dev/null || true
git status --short 2>/dev/null || true

section "kernel"
uname -a

section "compiler"
gcc --version 2>/dev/null || true

section "cpu"
lscpu 2>/dev/null || true

section "numa"
numactl --hardware 2>/dev/null || true

section "persistent-memory mount"
echo "PMEM_MOUNT=$PMEM_MOUNT"
echo "HBALLOC_PMEM_DIR=$PMEM_DIR"
findmnt -T "$PMEM_MOUNT" -o TARGET,SOURCE,FSTYPE,SIZE,USED,AVAIL,OPTIONS 2>/dev/null || true

section "ndctl"
ndctl list 2>/dev/null || true
