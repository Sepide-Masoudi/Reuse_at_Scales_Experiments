#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -lt 2 ]]; then
    echo "usage: $0 CONFIG BENCHMARK_BINARY" >&2
    exit 2
fi

CONFIG="$1"
BENCH="$2"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -f "$CONFIG" ]]; then
    echo "configuration file not found: $CONFIG" >&2
    exit 2
fi

if [[ ! -x "$BENCH" ]]; then
    echo "benchmark binary is not executable: $BENCH" >&2
    exit 2
fi

set -a
. "$CONFIG"
set +a

SIZE="${SIZE:-64}"
NOBJ="${NOBJ:-1000000}"
ITR="${ITR:-100}"
THREAD_COUNTS="${THREAD_COUNTS:-1 2 4 8 16 32 64 128}"
PMEM_MOUNT="${PMEM_MOUNT:-/mnt/pmem}"
PMEM_DIR="${HBALLOC_PMEM_DIR:-$PMEM_MOUNT/HBalloc}"
RESULTS_DIR="${RESULTS_DIR:-/tmp/hballoc-results}"

"$ROOT_DIR/scripts/check_env.sh"
mkdir -p "$RESULTS_DIR"

stamp="$(date +%Y%m%d-%H%M%S)"
log="$RESULTS_DIR/hballoc-thread-scaling-$stamp.log"

{
    echo "HBalloc thread-scaling benchmark"
    echo "date=$(date -Is)"
    echo "benchmark=$BENCH"
    echo "SIZE=$SIZE"
    echo "NOBJ=$NOBJ"
    echo "ITR=$ITR"
    echo "THREAD_COUNTS=$THREAD_COUNTS"
    echo "PMEM_MOUNT=$PMEM_MOUNT"
    echo "HBALLOC_PMEM_DIR=$PMEM_DIR"
    echo

    for threads in $THREAD_COUNTS; do
        find "$PMEM_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
        export HBALLOC_PMEM_DIR="$PMEM_DIR"

        echo "===== threads=$threads ====="
        "$BENCH" "$SIZE" "$NOBJ" "$ITR" "$threads"
        echo
    done
} 2>&1 | tee "$log"

echo "wrote log: $log"
