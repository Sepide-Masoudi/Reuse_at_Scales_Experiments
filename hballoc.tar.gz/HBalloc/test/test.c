#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include "../src/include/HBalloc.h"
#include <stdint.h>
#include <pthread.h>

#define MAXT 128
#define MAXN 1000000

pthread_t tid[MAXT];
PP pointers[MAXT][MAXN];
long long completed_allocs[MAXT];
long long completed_frees[MAXT];


int SIZE;
int ITR;
int N;
int T;

double GetTimeInSeconds(void)
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return (double)t.tv_sec + (double)t.tv_usec / 1000000.0;
}

void *test(void *arg)
{
    int n = N / T;
    int id = *(int*)arg;
    for(int itr = 0; itr < ITR; itr++){
        for(int i=0; i<n; i++){
            pointers[id][i] = hballoc_malloc(SIZE);
            if(pointers[id][i] == NPP){
                fprintf(stderr, "Thread %d received a null persistent pointer\n", id);
                exit(1);
            }
            completed_allocs[id]++;
        }
        for(int i=0; i<n; i++){
            hballoc_free(pointers[id][i], SIZE);
            completed_frees[id]++;
        }
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    if(argc != 5){
        printf("Usage: %s SIZE NOBJ ITR T\n", argv[0]);
        exit(0);
    }

    SIZE = atoi(argv[1]);
    N = atoi(argv[2]);
    ITR = atoi(argv[3]);
    T = atoi(argv[4]);
    
    if(T > MAXT || N / T > MAXN){
        printf("Too large NOBJ or T!\n");
        exit(0);
    }

    printf("Allocating %d %d-byte objects with %d working threads, repeating for %d iterations.\n",
        N, SIZE, T, ITR
    );

    int *id = malloc(T*sizeof(int));
    for(int i=0; i < T; i++)
      id[i] = i;
    
    const char *pmem_dir = getenv("HBALLOC_PMEM_DIR");
    if (pmem_dir == NULL)
        pmem_dir = "/mnt/pmem0/HBalloc";

    hballoc_start(pmem_dir, 32 * 1024 * 1024 * 1024ULL);
    
    double t1 = GetTimeInSeconds();
    
    for(int i = 0; i < T; i++){
        int ret = pthread_create( &tid[i], NULL, test, &id[i]);
        if(ret != 0){
            fprintf(stderr, "pthread_create failed for thread %d: %d\n", i, ret);
            exit(1);
        }
    }
    
    for(int i = 0; i < T; i++){
        int ret = pthread_join( tid[i], NULL);
        if(ret != 0){
            fprintf(stderr, "pthread_join failed for thread %d: %d\n", i, ret);
            exit(1);
        }
    }

    double t2 = GetTimeInSeconds();

    hballoc_exit();

    double t3 = GetTimeInSeconds();
    double elapsed = t2 - t1;
    double allocs = (double)(N / T) * T * ITR;
    long long observed_allocs = 0;
    long long observed_frees = 0;
    for(int i = 0; i < T; i++){
        observed_allocs += completed_allocs[i];
        observed_frees += completed_frees[i];
    }
    if(observed_allocs != (long long)allocs || observed_frees != (long long)allocs){
        fprintf(stderr, "Operation count mismatch: allocs=%lld frees=%lld expected=%.0f\n",
                observed_allocs, observed_frees, allocs);
        exit(1);
    }

    printf("Execution time = %.2f s\n", elapsed);
    printf("Shutdown time = %.2f s\n", t3 - t2);
    printf("Verified operations = %lld allocations + %lld frees\n", observed_allocs, observed_frees);
    printf("Allocation throughput = %.2f Mops/s\n", allocs / 1000000.0 / elapsed);
    printf("Malloc+free throughput = %.2f Mops/s\n", allocs * 2 / 1000000.0 / elapsed);

    return 0;
}
