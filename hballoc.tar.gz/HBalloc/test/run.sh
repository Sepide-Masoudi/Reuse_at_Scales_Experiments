rm test
gcc -o test test.c ../src/*.c -lpthread

PMEM_DIR="${HBALLOC_PMEM_DIR:-/mnt/pmem/HBalloc}"
rm -rf "$PMEM_DIR"
mkdir -p "$PMEM_DIR"
export HBALLOC_PMEM_DIR="$PMEM_DIR"

echo "Running local pmem test in $PMEM_DIR..."
./test 64 1000000 100 128