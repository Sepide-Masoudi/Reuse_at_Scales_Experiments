#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include <sched.h>
#include "../src/include/HBalloc.h"
#include <stdint.h>
#include <numa.h>

#define MAXT 128
#define MAXN 1000000

pthread_t tid[MAXT];
PP pointers[MAXT][MAXN];

int SIZE;
int ITR;
int N;
int T;
struct bitmask *socket1_cpus;

/**
 * Bind a pthread to a specific core in socket 1.
 * This ensures all threads are restricted to a single NUMA node.
 */
int bind_thread_to_core(int core_id) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(core_id, &cpuset);
    
    pthread_t current_thread = pthread_self();
    if (pthread_setaffinity_np(current_thread, sizeof(cpu_set_t), &cpuset) != 0) {
        perror("pthread_setaffinity_np");
        return -1;
    }
    return 0;
}

int socket1_to_cpu(int thread_id, struct bitmask *mask) {
    int total_cores = 0;
    for (int cpu = 0; cpu < mask->size; cpu++) {
        if (numa_bitmask_isbitset(mask, cpu))
            total_cores++;
    }
    if (total_cores == 0)
        return -1;

    int target = thread_id % total_cores;
    int cpu_count = 0;
    for (int cpu = 0; cpu < mask->size; cpu++) {
        if (numa_bitmask_isbitset(mask, cpu)) {
            if (cpu_count == target)
                return cpu;
            cpu_count++;
        }
    }
    return -1;
}

double GetTimeInSeconds(void)
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return (double)t.tv_sec + (double)t.tv_usec / 1000000.0;
}

void *test(void *arg)
{
    int id = *(int*)arg;
    int n = N / T;
    
    /* Bind this thread to a specific core in socket 1 */
    int core_id = socket1_to_cpu(id, socket1_cpus);
    if (core_id < 0) {
        fprintf(stderr, "Thread %d failed to map to socket 1 core\n", id);
        return NULL;
    }
    
    if (bind_thread_to_core(core_id) != 0) {
        fprintf(stderr, "Thread %d failed to bind to core %d\n", id, core_id);
        return NULL;
    }
    
    for(int itr = 0; itr < ITR; itr++){
        for(int i=0; i<n; i++)
            pointers[id][i] = hballoc_malloc(SIZE);
        for(int i=0; i<n; i++)
            hballoc_free(pointers[id][i], SIZE);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    if(argc != 5){
        printf("Usage: %s SIZE NOBJ ITR T\n", argv[0]);
        printf("  SIZE: Object size in bytes\n");
        printf("  NOBJ: Total number of objects to allocate\n");
        printf("  ITR:  Number of iterations\n");
        printf("  T:    Number of threads (should not exceed cores in single socket)\n");
        exit(0);
    }

    SIZE = atoi(argv[1]);
    N = atoi(argv[2]);
    ITR = atoi(argv[3]);
    T = atoi(argv[4]);
    
    if(T > MAXT || N / T > MAXN){
        printf("Too large NOBJ or T!\n");
        exit(0);
    }

    /* Check NUMA availability */
    if (numa_available() < 0) {
        fprintf(stderr, "Warning: NUMA not available. Continuing without NUMA binding.\n");
    } else {
        socket1_cpus = numa_allocate_cpumask();
        if (numa_node_to_cpus(1, socket1_cpus) < 0) {
            fprintf(stderr, "Warning: Failed to get CPUs for socket 1.\n");
        } else {
            int num_cores_in_socket = 0;
            for (int cpu = 0; cpu < socket1_cpus->size; cpu++) {
                if (numa_bitmask_isbitset(socket1_cpus, cpu))
                    num_cores_in_socket++;
            }
            printf("Socket 1 has %d cores. Current test uses %d threads.\n", 
                   num_cores_in_socket, T);
            if (T > num_cores_in_socket) {
                fprintf(stderr, "Warning: Number of threads (%d) exceeds cores in socket 1 (%d).\n"
                                "Some threads will share cores.\n", T, num_cores_in_socket);
            }
        }
    }

    printf("=== Single Socket Test ===\n");
    printf("Allocating %d %d-byte objects with %d working threads (restricted to socket 1), "
           "repeating for %d iterations.\n", N, SIZE, T, ITR);

    int *id = malloc(T * sizeof(int));
    for(int i = 0; i < T; i++)
      id[i] = i;
    
    const char *pmem_dir = getenv("HBALLOC_PMEM_DIR");
    if (pmem_dir == NULL)
        pmem_dir = "./pmem0/HBalloc";

    hballoc_start(pmem_dir, 32 * 1024 * 1024 * 1024ULL);
    
    double t1 = GetTimeInSeconds();
    
    for(int i = 0; i < T; i++)
        pthread_create(&tid[i], NULL, test, &id[i]);
    
    for(int i = 0; i < T; i++)
        pthread_join(tid[i], NULL);

    hballoc_exit();

    double t2 = GetTimeInSeconds();
    double elapsed_time = t2 - t1;
    double throughput = N * ITR / 1000000.0 / elapsed_time;
    
    printf("Time = %.2f s\n", elapsed_time);
    printf("Throughput = %.2f Mops/s\n", throughput);
    printf("=== Test Complete ===\n");

    free(id);
    return 0;
}
