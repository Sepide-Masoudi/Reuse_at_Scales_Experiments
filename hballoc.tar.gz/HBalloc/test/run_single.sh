#!/bin/bash
# Run the HBalloc thread test on CPU socket 1 only.

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# The CPU cores on socket 1 are 26-51 and 78-103 on the processor.
SOCKET1_CPUS="${SOCKET1_CPUS:-26-51,78-103}"
THREAD_COUNTS=(1 2 4 8 16 32 64 128)
SIZE="${SIZE:-64}"
NOBJ="${NOBJ:-1000000}"
ITR="${ITR:-100}"
PMEM_DIR="${HBALLOC_PMEM_DIR:-/mnt/pmem/HBalloc}"
PMEM_MOUNT="${PMEM_MOUNT:-/mnt/pmem}"

if ! findmnt -T "$PMEM_MOUNT" -n -o OPTIONS | grep -q 'dax'; then
    echo "HBalloc requires a DAX-mounted persistent-memory filesystem: $PMEM_MOUNT" >&2
    exit 1
fi

if [[ ! -d "$PMEM_DIR" || ! -w "$PMEM_DIR" ]]; then
    echo "HBalloc requires a writable persistent-memory directory: $PMEM_DIR" >&2
    echo "Create it once with:" >&2
    echo "  sudo mkdir -p $PMEM_DIR" >&2
    echo "  sudo chown $(id -u):$(id -g) $PMEM_DIR" >&2
    exit 1
fi

gcc -O3 -o test test.c ../src/*.c -lpthread

echo "Running HBalloc thread test on socket 1 CPUs: $SOCKET1_CPUS"
echo "Parameters: SIZE=$SIZE NOBJ=$NOBJ ITR=$ITR"

for threads in "${THREAD_COUNTS[@]}"; do
    find "$PMEM_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
    export HBALLOC_PMEM_DIR="$PMEM_DIR"

    echo
    echo "===== threads=$threads ====="
    taskset -c "$SOCKET1_CPUS" ./test "$SIZE" "$NOBJ" "$ITR" "$threads"
done
