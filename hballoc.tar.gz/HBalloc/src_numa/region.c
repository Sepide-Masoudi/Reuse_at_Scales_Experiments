#include "include/region.h"
#include "include/cas.h"
#include "include/hash.h"
#include "include/tcache.h"
#include "include/config.h"
#include "include/numa_local.h"
#include <sched.h>

extern void *RegionBaseAddr;
extern void *RegionBaseAddrByNode[2];
extern size_t REGION_NUM;
extern size_t REGION_NUM_PER_NODE;

static size_t node_pool_begin(uint64_t node)
{
    return 0;
}

static size_t node_pool_end(uint64_t node)
{
    return REGION_NUM_PER_NODE;
}

static struct RegionHeader *try_region(uint64_t node, size_t region_id, pthread_t tid)
{
    struct RegionHeader *prh = (struct RegionHeader *)(RegionBaseAddrByNode[node] + region_id * REGION_SIZE);
    if(CAS((volatile uint64_t*)&(prh->occupied), 0, tid) == true)
        return prh;
    return NULL;
}

static struct RegionHeader *try_region_pool(struct TCACHE *tc, uint64_t node)
{
    pthread_t tid = tc->occupied;
    size_t begin = node_pool_begin(node);
    size_t end = node_pool_end(node);
    size_t count = end - begin;
    if(count == 0)
        return NULL;

    size_t h1 = begin + (tc->h1 % count);
    struct RegionHeader *prh = try_region(node, h1, tid);
    if(prh != NULL)
        return prh;

    size_t h2 = begin + (tc->h2 % count);
    prh = try_region(node, h2, tid);
    if(prh != NULL)
        return prh;

    size_t h3 = begin + (tc->h3 % count);
    prh = try_region(node, h3, tid);
    if(prh != NULL)
        return prh;

    for(size_t scanned = 1; scanned < count; scanned++){
        size_t region_id = begin + ((h3 - begin + scanned) % count);
        prh = try_region(node, region_id, tid);
        if(prh != NULL)
            return prh;
    }
    return NULL;
}

struct RegionHeader *occupyAregion(struct TCACHE *tc)
{
    while(true){
        uint64_t local_node = hballoc_normalize_numa_node(tc->numa_node);

        struct RegionHeader *prh = try_region_pool(tc, local_node);
        if(prh != NULL)
            return prh;

        for(uint64_t node = 0; node < HBALLOC_NUMA_NODES; node++){
            if(node == local_node)
                continue;
            prh = try_region_pool(tc, node);
            if(prh != NULL)
                return prh;
        }

        sched_yield();
    }
}


void releaseAregion(struct RegionHeader *r)
{
    r->occupied = 0;
}
