#ifndef NUMA_LOCAL_H
#define NUMA_LOCAL_H 1

#include <stdint.h>
#include <sched.h>
#include <sys/syscall.h>
#include <unistd.h>

#define HBALLOC_NUMA_NODES 2ULL

static inline uint64_t hballoc_normalize_numa_node(uint64_t node)
{
    return node % HBALLOC_NUMA_NODES;
}

static inline uint64_t hballoc_current_numa_node(void)
{
    unsigned cpu = 0;
    unsigned node = 0;

#ifdef SYS_getcpu
    if (syscall(SYS_getcpu, &cpu, &node, NULL) == 0)
        return hballoc_normalize_numa_node(node);
#endif

    int current_cpu = sched_getcpu();
    if (current_cpu >= 26 && current_cpu <= 51)
        return 1;
    if (current_cpu >= 78 && current_cpu <= 103)
        return 1;
    return 0;
}

#endif
