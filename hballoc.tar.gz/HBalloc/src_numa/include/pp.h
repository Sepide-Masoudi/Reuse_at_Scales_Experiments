#ifndef PP_H
#define PP_H

#include <time.h>
#include <stdint.h>

#define PP_NODE_SHIFT 63
#define PP_NODE_MASK (1ULL << PP_NODE_SHIFT)
#define PP_OFFSET_MASK (~PP_NODE_MASK)

typedef uint64_t oid_t;

typedef oid_t PP;

typedef struct{
    PP pp;
    void *va;
}PP2VA_PAIR;

oid_t get_oid(void);
PP getPP(void *va);
void freePP(PP pp);
void *pp2va(PP pp);

#endif
